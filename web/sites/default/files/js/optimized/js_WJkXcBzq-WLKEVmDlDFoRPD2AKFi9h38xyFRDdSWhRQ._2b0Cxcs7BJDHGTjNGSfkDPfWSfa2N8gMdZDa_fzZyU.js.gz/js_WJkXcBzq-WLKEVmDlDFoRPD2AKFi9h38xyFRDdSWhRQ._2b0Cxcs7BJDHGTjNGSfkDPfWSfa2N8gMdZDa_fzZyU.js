/**
 * @file
 * Global utilities.
 *
 */
(function($, Drupal) {

  'use strict';

  Drupal.behaviors.mycustom_bootstrap_sass = {
    attach: function(context, settings) {

      // Custom code here

    }
  };

})(jQuery, Drupal);